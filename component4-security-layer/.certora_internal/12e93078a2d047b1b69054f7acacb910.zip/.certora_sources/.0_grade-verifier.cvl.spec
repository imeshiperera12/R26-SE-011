/*
 * grade-verifier.cvl
 * Certora Verification Language (CVL 2) specification for GradeVerifier.sol
 *
 * Research: Blockchain-Based Transparent and Secure Academic Grading System
 * Component 4: Security, Privacy & Verification Layer
 * Author: Susara Perera (IT22276346) | SLIIT
 *
 * Properties verified
 * -------------------
 * ACCESS CONTROL
 *   AC1 - Only the owner can pause or unpause the contract
 *   AC2 - Only the owner can call initialize()
 *   AC3 - verifyProof reverts when the contract is paused
 *   AC4 - verifyProof is a pure view (no state mutation)
 *
 * STATE INVARIANTS
 *   SI1 - verificationKeySet never reverts to false once true
 *   SI2 - proofCount is monotonically non-decreasing
 *   SI3 - A call to verifyProof (view fn) never increments proofCount
 *   SI4 - Contract ETH balance is always zero
 *
 * ARITHMETIC SAFETY
 *   AR1 - Public inputs inside the BN254 scalar field do not cause unexpected reverts
 */

using GradeVerifier as verifier;

// ── Method declarations ──────────────────────────────────────────────────────
// envfree = these getters do not depend on msg.sender / block context

methods {
    function owner()              external returns (address) envfree;
    function paused()             external returns (bool)    envfree;
    function verificationKeySet() external returns (bool)    envfree;
    function proofCount()         external returns (uint256) envfree;
}

// ============================================================================
// AC1 — Only the owner can toggle the paused flag
// ============================================================================
rule AC1_onlyOwnerCanChangePausedState(method f) {
    bool pausedBefore = paused();

    env e;
    calldataarg args;
    f(e, args);

    bool pausedAfter = paused();

    assert pausedBefore != pausedAfter => e.msg.sender == owner(),
        "AC1: only the owner may change the paused flag";
}

// ============================================================================
// AC2 — Only the owner can call initialize()
// ============================================================================
rule AC2_onlyOwnerCanInitialize() {
    env e;
    bool vksBefore = verificationKeySet();

    initialize(e);

    bool vksAfter = verificationKeySet();

    // If initialize changed the VKS flag the caller must be the owner
    assert vksBefore != vksAfter => e.msg.sender == owner(),
        "AC2: only the owner may call initialize()";
}

// ============================================================================
// AC3 — verifyProof must revert when the contract is paused
// ============================================================================
rule AC3_verifyProofRevertsWhenPaused(GradeVerifier.Proof proof, uint256[2] input) {
    env e;
    require paused() == true;

    verifyProof@withrevert(e, proof, input);

    assert lastReverted,
        "AC3: verifyProof must revert when the contract is paused";
}

// ============================================================================
// AC4 — verifyProof must not mutate any storage slot
// ============================================================================
rule AC4_verifyProofIsView(GradeVerifier.Proof proof, uint256[2] input) {
    env e;
    require e.msg.value == 0;

    storage before = lastStorage;
    verifyProof@withrevert(e, proof, input);
    storage after = lastStorage;

    assert before == after,
        "AC4: verifyProof must not change contract storage";
}

// ============================================================================
// SI1 — verificationKeySet never reverts to false once set to true
//        (initialize() is excluded from the inductive step because it is the
//         only function that may legitimately change verificationKeySet)
// ============================================================================
rule SI1_verificationKeyNeverCleared(method f)
    filtered { f -> f.selector != sig:GradeVerifier.initialize().selector }
{
    require verificationKeySet() == true;

    env e;
    calldataarg args;
    f(e, args);

    assert verificationKeySet() == true,
        "SI1: verificationKeySet must remain true once set";
}

// ============================================================================
// SI2 — proofCount is monotonically non-decreasing across all functions
// ============================================================================
rule SI2_proofCounterNeverDecreases(method f) {
    uint256 countBefore = proofCount();

    env e;
    calldataarg args;
    f(e, args);

    assert proofCount() >= countBefore,
        "SI2: proofCount must never decrease";
}

// ============================================================================
// SI3 — Calling verifyProof (a view function) never increments proofCount
// ============================================================================
rule SI3_viewCallDoesNotIncrementCounter(GradeVerifier.Proof proof, uint256[2] input) {
    env e;
    uint256 countBefore = proofCount();

    verifyProof@withrevert(e, proof, input);

    assert proofCount() == countBefore,
        "SI3: proofCount must be unchanged after a call to verifyProof";
}

// ============================================================================
// SI4 — The contract must never hold ETH (no payable functions)
// ============================================================================
invariant SI4_contractBalanceAlwaysZero()
    nativeBalances[currentContract] == 0;

// ============================================================================
// AR1 — verifyProof must not revert for in-field public inputs (unless paused)
//        BN254 scalar field: r = 21888242871839275222246405745257275088548364400416034343698204186575808495617
// ============================================================================
definition BN254_R() returns uint256 =
    21888242871839275222246405745257275088548364400416034343698204186575808495617;

rule AR1_publicInputsInScalarField(GradeVerifier.Proof proof, uint256[2] input) {
    env e;
    require input[0] < BN254_R();
    require input[1] < BN254_R();

    verifyProof@withrevert(e, proof, input);

    // The only acceptable reason for a revert with in-field inputs is the pause guard
    assert !lastReverted || paused(),
        "AR1: verifyProof must not revert for in-field public inputs unless paused";
}
